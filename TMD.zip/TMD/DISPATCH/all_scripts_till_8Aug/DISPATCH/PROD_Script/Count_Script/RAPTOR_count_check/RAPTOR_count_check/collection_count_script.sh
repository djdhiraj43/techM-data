#!/bin/bash

#. /opt/app/nas/mongodbscripts/purge_db_details.cfg
. /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/db_details_for_count.cfg

echo "$host $port $user $pwd $authdb"
echo "Counting Started....."

if [ "$switch" == "ON" ]
then


dt=`date +%d%b%Y_%H_%M`;
#lFile="RAPTOR_count_$dt";
logFile="RAPTOR_count_$dt".log

rm /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/RAPTOR_count*

/opt/app/mongo/mongodb_mms_latest_version/mongodb-linux-x86_64-3.2.11-ent/bin/mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/mongodb_count_script.js | tee /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/"$logFile" >> /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/permanent_RPTOR_cnt.log

echo "Hi,
Please find the collection count details of RAPTOR in the attachment for DATE:`date`"|mail -s "Collection count on: `date`" -a /opt/app/workload/deployments/scripts/mongodbscripts/RaptorMongoCount/"$logFile" ak694a@att.com vc364s@att.com vn2217@att.com

#echo "$logFile"

echo "Counting End."
fi
