#!/bin/bash
. /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/scheduledata_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "MW Schedule Data Mapping Started....."
/opt/app/workload/deployments/servers/mongodb-linux-x86_64-enterprise-rhel70-3.4.10/bin/mongo "$host":"$port"/"$connectdb" /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/MW_SCH/sch_mw.js >> /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/MW_SCH/connect_sch_mw.log
echo "MW Schedule Data Mapping End."
