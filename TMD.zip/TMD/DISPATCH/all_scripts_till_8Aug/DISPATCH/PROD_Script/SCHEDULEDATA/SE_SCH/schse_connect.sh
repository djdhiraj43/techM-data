#!/bin/bash
. /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/scheduledata_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "SE Schedule Data Mapping Started....."
/opt/app/workload/deployments/servers/mongodb-linux-x86_64-enterprise-rhel70-3.4.10/bin/mongo "$host":"$port"/"$connectdb" /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/SE_SCH/sch_se.js >> /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/SE_SCH/sch_se.log
echo "SE Schedule Data Mapping End."
