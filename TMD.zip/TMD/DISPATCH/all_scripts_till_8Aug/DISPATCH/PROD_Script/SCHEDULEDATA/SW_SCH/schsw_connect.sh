#!/bin/bash
. /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/scheduledata_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "SW Schedule Data Mapping Started....."
/opt/app/workload/deployments/servers/mongodb-linux-x86_64-enterprise-rhel70-3.4.10/bin/mongo "$host":"$port"/"$connectdb" /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/SW_SCH/sch_sw.js >> /opt/app/workload/deployments/scripts/mongodbscripts/SCHEDULEDATA/SW_SCH/sch_sw.log
echo "SW Schedule Data Mapping End."
