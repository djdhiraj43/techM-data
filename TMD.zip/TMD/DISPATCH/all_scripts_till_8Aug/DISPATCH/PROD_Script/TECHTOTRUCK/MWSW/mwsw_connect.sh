#!/bin/bash
. /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/techtotruck_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "Mapping Started....."
#mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /tmp/map_tech_truck.js
/opt/app/workload/deployments/servers/mongodb-linux-x86_64-enterprise-rhel70-3.4.10/bin/mongo "$host":"$port"/"$connectdb" /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/MWSW/mwsw_techtotruck.js >> /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/MWSW/mwswlog.log
echo "Mapping End."
