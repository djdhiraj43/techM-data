var bulkOp = db.MAP_TECH_TRUCK_MWSW.initializeUnorderedBulkOp()
var techUIDs_mwsw = db.TELCO.GPS_FKEY_MWSW.distinct("TECHNICIAN_UUID",{$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}]})
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
var mwsw_count = 0
var x = 1000
var counter = 0
print('Mapping MWSW Started at : '+ new Date())
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_mwsw}}).forEach(function(row){

try{
from_date = new Date(row.FROM_WHEN)
to_when = new Date(row.TO_WHEN)
tdate = new Date(todaydate)

if(from_date <= tdate && to_when >= tdate)
{
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
function(doc){
from_date9 = new Date(doc.FROM_WHEN)
to_when9 = new Date(doc.TO_WHEN)
if(from_date9 <= tdate && to_when9 >= tdate)
{
bulkOp.find( {"TECHNICIAN_UUID":row.TECHNICIAN_UUID} ).upsert().update({
$set: {
"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}
});
mwsw_count = mwsw_count + 1
}
})
}
counter ++
if( counter % x == 0){
bulkOp.execute()
bulkOp = db.MAP_TECH_TRUCK_MWSW.initializeUnorderedBulkOp()
}
}
catch(err)
{
print("ERROR : "+ err)
}
})
bulkOp.execute()
print('MWSW Total Insert/Update Count : '+ mwsw_count + ' Mapping MWSW Ends at : '+ new Date())
