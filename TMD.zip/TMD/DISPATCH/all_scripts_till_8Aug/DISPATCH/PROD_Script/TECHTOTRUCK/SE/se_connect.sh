#!/bin/bash
. /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/techtotruck_db_details.cfg
echo "$host $port $user $pwd $authdb"
echo "SE Mapping Started....."
/opt/app/workload/deployments/servers/mongodb-linux-x86_64-enterprise-rhel70-3.4.10/bin/mongo "$host":"$port"/"$connectdb" /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/SE/se_techtotruck.js >> /opt/app/workload/deployments/scripts/mongodbscripts/TECHTOTRUCK/SE/selog.log
echo "SE Mapping End."
