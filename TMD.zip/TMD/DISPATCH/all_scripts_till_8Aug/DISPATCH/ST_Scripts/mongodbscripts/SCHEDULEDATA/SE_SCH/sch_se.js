todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
var collExists_se = db.MAPTECHSCHEDULEVACATION_SE_8MAR2018.count()
if(collExists_se>0)
{
db.MAPTECHSCHEDULEVACATION_SE_8MAR2018.remove({})
}
print('SE Starts at : ' + new Date())
db.FORCESE.XBFTECHDATESCHEDPARAMS_T_SE.find({}).forEach(function(doc){
schedule_date = new Date(doc.SCHEDULEDATE)
schedule_date= new Date((((schedule_date.getMonth()+1) < 10 )? "0"+ (schedule_date.getMonth()+1):(schedule_date.getMonth()+1))+"/"+
((schedule_date.getDate() < 10)? "0"+ schedule_date.getDate():schedule_date.getDate())+"/"+schedule_date.getFullYear())
tdate = new Date(todaydate)
var formateddate="";
var lunchenddate="";
if((schedule_date.getTime()) === (tdate.getTime()))
{
if((doc.LUNCHSTARTTIME == "null") || (doc.LUNCHSTARTTIME == "") || (doc.LUNCHSTARTTIME == null))
{
doc.LUNCHSTARTTIME =""
}
else
{
strdate = doc.LUNCHSTARTTIME
strdate = strdate.replace(/-/g,'/').replace(/:/,' ')
formateddate = new Date(strdate)
formateddate.setMinutes(formateddate.getMinutes() + parseInt((doc.LUNCHLENGTH =='null' || doc.LUNCHLENGTH =='') ? 0 : doc.LUNCHLENGTH))
lunchenddate  = [
formateddate.getFullYear(),
(((formateddate.getMonth()+1) < 10 )? "0"+ (formateddate.getMonth()+1):(formateddate.getMonth()+1)) ,
((formateddate.getDate() < 10)? "0"+ formateddate.getDate():formateddate.getDate())].join('/')+' '+
[((formateddate.getHours() < 10)? "0"+ formateddate.getHours():formateddate.getHours()),
((formateddate.getMinutes() < 10)? "0"+ formateddate.getMinutes():formateddate.getMinutes()),
((formateddate.getSeconds() < 10)? "0"+ formateddate.getSeconds():formateddate.getSeconds())].join(':');
lunchenddate = lunchenddate.replace(/\//g,'-').replace(/ /,':')
}

db.MAPTECHSCHEDULEVACATION_SE_8MAR2018.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE
,"LUNCHSTARTTIME":doc.LUNCHSTARTTIME,"LUNCHENDTIME":lunchenddate,"SCHEDULESTART":doc.SCHEDULESTART
,"SCHEDULEEND":doc.SCHEDULEEND,"SCHEDULEPROFILE":doc.SCHEDULEPROFILE,"OBJECTTIMEZONE":doc.OBJECTTIMEZONE})
}
})
var se_count =db.MAPTECHSCHEDULEVACATION_SE_8MAR2018.count()
print('SE count: ' + se_count + " SE Ends at : " + new Date())
