#!/bin/bash
. /opt/app/nas/mongodbscripts/SCHEDULEDATA/scheduledata_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "SE Schedule Data Mapping Started....."
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/SCHEDULEDATA/SE_SCH/sch_se.js >> /opt/app/nas/mongodbscripts/SCHEDULEDATA/SE_SCH/sch_se.log
echo "SE Schedule Data Mapping End."
