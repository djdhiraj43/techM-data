#!/bin/bash
. /opt/app/nas/mongodbscripts/TECHTOTRUCK/techtotruck_db_details.cfg
echo "$host $port $user $pwd $authdb $connectdb"
echo "Mapping Started....."
#mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /tmp/map_tech_truck.js
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/TECHTOTRUCK/MWSW/mwsw_techtotruck.js >> /opt/app/nas/mongodbscripts/TECHTOTRUCK/MWSW/mwswlog.log
echo "Mapping End."
