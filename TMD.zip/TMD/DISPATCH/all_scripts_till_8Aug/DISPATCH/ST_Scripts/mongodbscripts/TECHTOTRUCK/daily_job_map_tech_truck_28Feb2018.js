var bulkOp = db.MAP_TECH_TRUCK_SE.initializeUnorderedBulkOp()
var techUIDs_se = db.TELCO.GPS_FKEY_SE.distinct("TECHNICIAN_UUID",{$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}]})
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
lastcreatedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
lastmodifiedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
var se_count = 0
var x = 1000
var counter = 0
print('Mapping SE Started at : '+ new Date())
db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
try{
if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
{
	from_date = new Date(row.FROM_WHEN)
	to_when = new Date(row.TO_WHEN)
	tdate = new Date(todaydate)
	
	if(from_date <= tdate && to_when >= tdate)
	{
		db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
		function(doc){
		from_date9 = new Date(doc.FROM_WHEN)
		to_when9 = new Date(doc.TO_WHEN)
		if(from_date9 <= tdate && to_when9 >= tdate)
		{
			bulkOp.find( {"TECHNICIAN_UUID":row.TECHNICIAN_UUID} ).upsert().update({
			$set: {
			"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}
			});
			se_count =se_count + 1
		}
		})
	}
}
counter ++
if( counter % x == 0){
bulkOp.execute()
bulkOp = db.MAP_TECH_TRUCK_SE.initializeUnorderedBulkOp()
}
}
catch(err)
{
	print("ERROR : "+ err)
}
})
bulkOp.execute()
print('SE Total Insert/Update Count : '+ se_count +' Mapping SE Ends at : '+ new Date())

var bulkOp = db.MAP_TECH_TRUCK_W.initializeUnorderedBulkOp()
var techUIDs_se = db.TELCO.GPS_FKEY_W.distinct("TECHNICIAN_UUID",{$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}]})
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
lastcreatedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
lastmodifiedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
var w_count = 0
var x = 1000
var counter = 0
print('Mapping W Started at : '+ new Date())
db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
try{
if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
{
	from_date = new Date(row.FROM_WHEN)
	to_when = new Date(row.TO_WHEN)
	tdate = new Date(todaydate)
	
	if(from_date <= tdate && to_when >= tdate)
	{
		db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
		function(doc){
		from_date9 = new Date(doc.FROM_WHEN)
		to_when9 = new Date(doc.TO_WHEN)
		if(from_date9 <= tdate && to_when9 >= tdate)
		{
			bulkOp.find( {"TECHNICIAN_UUID":row.TECHNICIAN_UUID} ).upsert().update({
			$set: {
			"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}
			});
			w_count = w_count + 1
		}
		})
	}
}
counter ++
if( counter % x == 0){
bulkOp.execute()
bulkOp = db.MAP_TECH_TRUCK_W.initializeUnorderedBulkOp()
}
}
catch(err)
{
	print("ERROR : "+ err)
}
})
bulkOp.execute()
print('W Total Insert/Update Count : '+ w_count + ' Mapping W Ends at : '+ new Date())

var bulkOp = db.MAP_TECH_TRUCK_MWSW.initializeUnorderedBulkOp()
var techUIDs_se = db.TELCO.GPS_FKEY_MWSW.distinct("TECHNICIAN_UUID",{$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}]})
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
lastcreatedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
lastmodifiedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
var mwsw_count = 0
var x = 1000
var counter = 0
print('Mapping MWSW Started at : '+ new Date())
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
try{
if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
{
	from_date = new Date(row.FROM_WHEN)
	to_when = new Date(row.TO_WHEN)
	tdate = new Date(todaydate)
	
	if(from_date <= tdate && to_when >= tdate)
	{
		db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
		function(doc){
		from_date9 = new Date(doc.FROM_WHEN)
		to_when9 = new Date(doc.TO_WHEN)
		if(from_date9 <= tdate && to_when9 >= tdate)
		{
			bulkOp.find( {"TECHNICIAN_UUID":row.TECHNICIAN_UUID} ).upsert().update({
			$set: {
			"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}
			});
			mwsw_count = mwsw_count + 1
		}
		})
	}
}
counter ++
if( counter % x == 0){
bulkOp.execute()
bulkOp = db.MAP_TECH_TRUCK_MWSW.initializeUnorderedBulkOp()
}
}
catch(err)
{
	print("ERROR : "+ err)
}
})
bulkOp.execute()
print('MWSW Total Insert/Update Count : '+ mwsw_count + ' Mapping MWSW Ends at : '+ new Date())
