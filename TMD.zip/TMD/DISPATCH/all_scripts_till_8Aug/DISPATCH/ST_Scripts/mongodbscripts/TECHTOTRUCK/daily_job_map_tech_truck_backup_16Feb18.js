todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
var se_insert_count=0
var se_update_count=0
var mwsw_insert_count=0
var mwsw_update_count=0
var w_insert_count=0
var w_update_count=0
lastcreatedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
lastmodifiedDate = new Date(new Date(ISODate()-1000*3600*24*1).setHours(0,0,0,0))
print('Mapping SE Started at : '+ new Date())
db.TELCO.GPS_FKEY_SE.find({$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}],"RECORD_TYPE":{$in:["7",7.0,7]}}).forEach(function(row){
    recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
	recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
	
    if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
    {       
        from_date = new Date(row.FROM_WHEN)
        to_when = new Date(row.TO_WHEN)
        tdate = new Date(todaydate) 
        if(from_date <= tdate && to_when >= tdate)
        {  
            db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
            function(doc)
            {  
                from_date9 = new Date(doc.FROM_WHEN)
		to_when9 = new Date(doc.TO_WHEN)
		if(from_date9 <= tdate && to_when9 >= tdate)
		{
		var techExists = db.MAP_TECH_TRUCK_SE.find({"TECHNICIAN_UUID":row.TECHNICIAN_UUID}).count()
                if(techExists == 0)
                {                   
                   db.MAP_TECH_TRUCK_SE.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}) 
			se_insert_count=se_insert_count+1
                }
                else
                { 
                    db.MAP_TECH_TRUCK_SE.update({"TECHNICIAN_UUID":row.TECHNICIAN_UUID},{$set:{"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}}) 
			se_update_count=se_update_count+1
                }
		}         
            })
        
        }   
    }
    
})
print('SE Insert Count : ' +se_insert_count+' Update Count :'+ se_update_count)
print('Mapping SE Ends at : '+ new Date())

print('Mapping MWSW Started at : '+ new Date())

db.TELCO.GPS_FKEY_MWSW.find({$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}],"RECORD_TYPE":{$in:["7",7.0,7]}}).forEach(function(row){
    recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
	recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
	
    if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
    {       
        from_date = new Date(row.FROM_WHEN)
        to_when = new Date(row.TO_WHEN)
        tdate = new Date(todaydate) 
        if(from_date <= tdate && to_when >= tdate)
        {  
            db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
            function(doc)
            {  
		from_date9 = new Date(doc.FROM_WHEN)
                to_when9 = new Date(doc.TO_WHEN)
                if(from_date9 <= tdate && to_when9 >= tdate)
		{
                var techExists = db.MAP_TECH_TRUCK_MWSW.find({"TECHNICIAN_UUID":row.TECHNICIAN_UUID}).count()
                if(techExists == 0)
                {
                   db.MAP_TECH_TRUCK_MWSW.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}) 
			mwsw_insert_count=mwsw_insert_count+1
                }
                else
                {
                    db.MAP_TECH_TRUCK_MWSW.update({"TECHNICIAN_UUID":row.TECHNICIAN_UUID},{$set:{"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}}) 
			mwsw_update_count = mwsw_update_count+1
                }
		}         
            })
        
        }   
    }
    
})
print('MWSW Insert Count : ' +mwsw_insert_count+' Update Count :'+ mwsw_update_count)
print('Mapping MWSW Ends at : '+ new Date())

print('Mapping W Started at : '+ new Date())

db.TELCO.GPS_FKEY_W.find({$and:[{"TECHNICIAN_UUID":{$ne:'null'}},{"TECHNICIAN_UUID":{$ne:''}}],"RECORD_TYPE":{$in:["7",7.0,7]}}).forEach(function(row){
    recordlastmodifiedDate = new Date(new Date(row.RecordUpdatedOn).setHours(0,0,0,0))
	recordcreatedDate = new Date(new Date(row.RecordCreatedOn).setHours(0,0,0,0))
	
    if((recordlastmodifiedDate.getTime() === lastmodifiedDate.getTime()) || (recordcreatedDate.getTime() === lastcreatedDate.getTime()))
    {       
        from_date = new Date(row.FROM_WHEN)
        to_when = new Date(row.TO_WHEN)
        tdate = new Date(todaydate) 
        if(from_date <= tdate && to_when >= tdate)
        {  
            db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
            function(doc)
            {   
		from_date9 = new Date(doc.FROM_WHEN)
                to_when9 = new Date(doc.TO_WHEN)
                if(from_date9 <= tdate && to_when9 >= tdate)
		{
                var techExists = db.MAP_TECH_TRUCK_W.find({"TECHNICIAN_UUID":row.TECHNICIAN_UUID}).count()
                if(techExists == 0)
                {
                   db.MAP_TECH_TRUCK_W.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}) 
			w_insert_count=w_insert_count+1
                }
                else
                { 
                    db.MAP_TECH_TRUCK_W.update({"TECHNICIAN_UUID":row.TECHNICIAN_UUID},{$set:{"TRUCK_ID_NUM":doc.TRUCK_ID_NUM}}) 
			w_update_count=w_update_count+1
                }
		}         
            })
        
        }   
    }
    
})
print('W Insert Count : ' +w_insert_count+' Update Count :'+ w_update_count)
print('Mapping W Ends at : '+ new Date())

