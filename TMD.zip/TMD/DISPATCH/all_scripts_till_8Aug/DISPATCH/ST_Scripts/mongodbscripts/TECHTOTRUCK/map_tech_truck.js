
var techUIDs_se = db.TELCO.GPS_FKEY_SE.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

var collExists_se = db.MAP_TECH_TRUCK_SE_TEST.count()
if(collExists_se>0)
{    
    db.MAP_TECH_TRUCK_SE_TEST.remove({})
}
db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate) 
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_SE_TEST.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_se_count = db.MAP_TECH_TRUCK_SE_TEST.count()
print("SE count : "+ map_se_count)

var techUIDs_mwsw = db.TELCO.GPS_FKEY_MWSW.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";


var collExists_mwsw = db.MAP_TECH_TRUCK_MWSW_TEST.count()
if(collExists_mwsw>0)
{    
    db.MAP_TECH_TRUCK_MWSW_TEST.remove({})
}
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_mwsw}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate) 
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_MWSW_TEST.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_mwsw_count = db.MAP_TECH_TRUCK_MWSW_TEST.count()
print("MWSW count : "+ map_mwsw_count)

var techUIDs_w = db.TELCO.GPS_FKEY_W.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

var collExists_w = db.MAP_TECH_TRUCK_W_TEST.count()
if(collExists_w>0)
{    
    db.MAP_TECH_TRUCK_W_TEST.remove({})
}
db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["7",7.0,7]},"TECHNICIAN_UUID":{$in:techUIDs_w}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate) 
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_W_TEST.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_w_count = db.MAP_TECH_TRUCK_W_TEST.count()
print("W count : "+ map_w_count)


