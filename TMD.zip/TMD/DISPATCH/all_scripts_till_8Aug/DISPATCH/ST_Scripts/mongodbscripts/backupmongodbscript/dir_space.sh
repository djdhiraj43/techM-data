#!/bin/bash

df -h /opt/app/workload/ | mail -s "This is the subject" db00494888@techmahindra.com
