#!/bin/bash





folder=$(date +%b%Y)

ar=(DISPATCH_CP
DISPATCH_CP1
DISPATCH_WF
DISPATCH_WF1
DISPATCH_WF10
DISPATCH_WF2
DISPATCH_WF5)


echo "dumping started on : $(date) " |& tee -a /opt/app/nas/MONGODBST_BACKUP.log

for i in "${ar[@]}"
do

echo "dumping for db : $i started on $(date) "|& tee -a /opt/app/nas/MONGODBST_BACKUP.log

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongodump --host zld04091.vci.att.com:37000 -d "$i" -o /opt/app/nas/MONGODBST_BACKUP/"$folder"_temp/ >> /opt/app/nas/MONGODBST_BACKUP.log

echo "dumping for db : $i finished on $(date) "|& tee -a /opt/app/nas/MONGODBST_BACKUP.log

done

echo "dumping for all dbs finished on : $(date) " |& tee -a /opt/app/nas/MONGODBST_BACKUP.log
