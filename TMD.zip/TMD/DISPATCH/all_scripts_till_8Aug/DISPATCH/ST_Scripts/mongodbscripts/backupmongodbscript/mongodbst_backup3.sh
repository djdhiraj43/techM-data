#!/bin/bash

##. /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc
. /opt/app/nas/mongodbscripts/backupmongodbscript/host_details.doc
. /opt/app/nas/mongodbscripts/backupmongodbscript/query.js

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo zld04091.vci.att.com:37000 < /opt/app/nas/mongodbscripts/backupmongodbscript/query.js > /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc

##echo "ar=(`cat /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc|grep -v "admin\|test\|local"|grep GB |cut -d" " -f1`)" > /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc

echo "ar=(`cat /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc|grep -v "admin\|test\|local"|grep GB |cut -d" " -f1`)" > /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc

. /opt/app/nas/mongodbscripts/backupmongodbscript/db_names.doc

echo "${ar[@]}"

folder=$(date +%b%Y)

echo "dumping started on : $(date) " >> /opt/app/nas/MONGODBST_BACKUP.log

for i in "${ar[@]}"
do

echo "dumping for db : $i started on $(date) " >> /opt/app/nas/MONGODBST_BACKUP.log

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongodump --host "$host_url":"$port" -d "$i" -o /opt/app/nas/MONGODBST_BACKUP/"$folder"_temp/ >> /opt/app/nas/MONGODBST_BACKUP.log 2>&1

echo "dumping for db : $i finished on $(date) " >> /opt/app/nas/MONGODBST_BACKUP.log

done

echo "dumping for all dbs finished on : $(date) " >> /opt/app/nas/MONGODBST_BACKUP.log
