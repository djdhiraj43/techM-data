use RAPTOR
db.ARADMIN.T1913_Update.findOne()
