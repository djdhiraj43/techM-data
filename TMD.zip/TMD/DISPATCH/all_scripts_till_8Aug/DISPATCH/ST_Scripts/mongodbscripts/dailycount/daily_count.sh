#!/bin/bash

. /opt/app/nas/mongodbscripts/dailycount/scheduledata_db_details.cfg

echo "$host $port $user $pwd $authdb"
echo "hourly count start...."
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/dailycount/daily_count_script.js >> /opt/app/nas/mongodbscripts/dailycount/count-data.log 
echo "hourly caount finish."
