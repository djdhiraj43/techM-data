var dbcount =  db.KeplerTechDispatchDetail.find().sort({_id:-1}).limit(10000)
print ("DispatchJourney_db_count : " + dbcount  )

var EDGE_MW = db.FORCEMW.XBFWR_T_MW.find().count()
print ("EDGE_MONGO_PROCESSING_MW Count : "  + EDGE_MW + " DateTime :" + new Date())

var EDGE_SW =db.FORCESW.XBFWR_T_SW.find().count()
print ("EDGE_MONGO_PROCESSING_SW Count : "  + EDGE_SW + " DateTime :" + new Date())

var EDGE_SE = db.FORCESE.XBFWR_T_SE.find().count()
print ("EDGE_MONGO_PROCESSING_SE Count : "  + EDGE_SE + " DateTime :" + new Date())

var EDGE_W = db.FORCEW.XBFWR_T_W.find().count()
print ("EDGE_MONGO_PROCESSING_W Count : "  + EDGE_W + " DateTime :" + new Date())

var VTS_MWSW= db.TELCO.VENDOR_LOCATION_MWSW.find().count()
print ("VTS_MONGO_PROCESSING_MWSW Count : "  + VTS_MWSW + " DateTime :" + new Date())

var VTS_SE= db.TELCO.VENDOR_LOCATION_SE.find().count()
print ("VTS_MONGO_PROCESSING_SE Count : "  + VTS_SE + " DateTime :" + new Date())

var VTS_W= db.TELCO.VENDOR_LOCATION_W.find().count()
print ("VTS_MONGO_PROCESSING_W Count : "  + VTS_W + " DateTime :" + new Date())

var SCH_MW = db.FORCEMW.XBFTECHDATESCHEDPARAMS_T_MW.find().count()
print ("SCH_MONGO_PROCESSING_MW Count : "  + SCH_MW + " DateTime :" + new Date())
var SCH_SW =db.FORCESW.XBFTECHDATESCHEDPARAMS_T_SW.find().count()
print ("SCH_MONGO_PROCESSING_SW Count : "  + SCH_SW + " DateTime :" + new Date())
var SCH_SE =db.FORCESE.XBFTECHDATESCHEDPARAMS_T_SE.find().count()
print ("SCH_MONGO_PROCESSING_SE Count : "  + SCH_SE + " DateTime :" + new Date())
var SCH_W =db.FORCEW.XBFTECHDATESCHEDPARAMS_T_W.find().count()
print ("SCH_MONGO_PROCESSING_W Count : "  + SCH_W + " DateTime :" + new Date())

var TT_MW =db.FORCEMW.XBFTECH_T_MW.find().count()
print ("TT_MONGO_PROCESSING_MW Count : "  + TT_MW + " DateTime :" + new Date())
var TT_SW =db.FORCESW.XBFTECH_T_SW.find().count()
print ("TT_MONGO_PROCESSING_SW Count : "  + TT_SW + " DateTime :" + new Date())
var TT_SE =db.FORCESE.XBFTECH_T_SE.find().count()
print ("TT_MONGO_PROCESSING_SE Count : "  + TT_SE + " DateTime :" + new Date())
var TT_W =db.FORCEW.XBFTECH_T_W.find().count()
print ("TT_MONGO_PROCESSING_W Count : "  + TT_W + " DateTime :" + new Date())

var VTSGPS_MWSW =db.TELCO.GPS_FKEY_MWSW.find().count()
print ("VTSGPS_MONGO_PROCESSING_MWSW Count : "  + VTSGPS_MWSW + " DateTime :" + new Date())
var VTSGPS_SE =db.TELCO.GPS_FKEY_SE.find().count()
print ("VTSGPS_MONGO_PROCESSING_SE Count : "  + VTSGPS_SE + " DateTime :" + new Date())
var VTSGPS_W =db.TELCO.GPS_FKEY_W.find().count()
print ("VTSGPS_MONGO_PROCESSING_W Count : "  + VTSGPS_W + " DateTime :" + new Date())

var DISPATCHJ =db.KeplerTechDispatchDetail.find().count()
print ("DISPATCHJ_MONGO_PROCESSING Count : "  + DISPATCHJ + " DateTime :" + new Date())
