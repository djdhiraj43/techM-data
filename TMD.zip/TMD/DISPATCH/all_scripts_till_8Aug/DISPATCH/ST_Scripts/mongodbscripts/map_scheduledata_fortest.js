todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

var mw_count =db.MAPTECHSCHEDULEVACATION_MW.count()
        print('MW count: ' + mw_count)

var sw_count =db.MAPTECHSCHEDULEVACATION_SW.count()
        print('SW count: ' + sw_count)

var se_count =db.MAPTECHSCHEDULEVACATION_SE.count()
        print('SE count: ' + se_count)

var w_count =db.MAPTECHSCHEDULEVACATION_W.count()
        print('W count: ' + w_count)

print('Today date : ' + todaydate)
