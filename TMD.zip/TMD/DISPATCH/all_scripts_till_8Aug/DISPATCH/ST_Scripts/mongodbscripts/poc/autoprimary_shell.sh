#!/bin/bash
PRIMARY=`/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo zld04096.vci.att.com:37000 --eval "printjson(rs.isMaster())" | grep "primary" | cut -d"\"" -f4`
echo "$PRIMARY"
SLENGTH=`echo -n $PRIMARY | wc -m`
echo "$SLENGTH"
if [ $SLENGTH -gt 0 ]
then
echo "in primary"
elif [ $SLENGTH -eq 0  ]
then
PRIMARY=`/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo zld04097.vci.att.com:37000 --eval "printjson(rs.isMaster())" | grep "primary" | cut -d"\"" -f4`
SLENGTH=`echo -n $PRIMARY | wc -m`
if [ $SLENGTH -gt 0 ]
then
echo "in primary1"
elif [ $SLENGTH -eq 0  ]
then
PRIMARY=`/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo zld04093.vci.att.com:37000 --eval "printjson(rs.isMaster())" | grep "primary" | cut -d"\"" -f4`
echo "$PRIMARY"
fi
fi
connectdb="DISPATCH"
test=`echo $PRIMARY | grep 'vci.att.com' | wc -m`
testpri=`echo $PRIMARY | cut -d":" -f1`
testport=`echo $PRIMARY | cut -d":" -f2`
if [ $test -eq 0 ]
then
testpri=$testpri".vci.att.com:"$testport
echo "$testpri"
else
testpri=$PRIMARY
fi
echo "$testpri"
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$testpri"/"$connectdb" /opt/app/nas/mongodbscripts/poc/autoprimary_test.js

