print('JS Scripts runs .....');
var c = db.MAPTECHTYPE_SE.count();
print(c)

