#!/bin/bash

#. /opt/app/nas/mongodbscripts/purge_db_details.cfg
. /opt/app/nas/mongodbscripts/purging/Dhiraj/purge_db_details_adv.cfg
echo "$host $port $user $pwd $authdb"
echo "Purging Started....."

echo "Purging Started for DISPATCH" >> /opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/DISPATCH /opt/app/nas/mongodbscripts/purging/Dhiraj/purging_script_tmp.js >>/opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

echo "Purging Finished for DISPATCH" >> /opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

echo "================================================================================"

echo "Purging Started for DISPATCH_Dev" >> /opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/DISPATCH_DEV /opt/app/nas/mongodbscripts/purging/Dhiraj/purging_script_tmp.js >>/opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

echo "Purging Finished for DISPATCH_Dev" >> /opt/app/nas/mongodbscripts/purging/Dhiraj/purge_details.log

echo "Purging End."
