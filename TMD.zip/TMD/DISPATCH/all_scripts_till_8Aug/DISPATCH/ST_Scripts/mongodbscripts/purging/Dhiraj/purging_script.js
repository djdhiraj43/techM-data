var isfunctionExists = db.system.js.find({"_id":"objectIdWithTimestamp"}).count()
if(isfunctionExists==0)
{
   db.system.js.save (
   {
     _id: "objectIdWithTimestamp",
     value: function objectIdWithTimestamp (timestamp) {

         if (typeof(timestamp) == 'string')
         {
             timestamp = new Date(timestamp);
         }


      var hexSeconds = Math.floor(timestamp/1000).toString(16);

    var constructedObjectId = ObjectId(hexSeconds + "0000000000000000");
    return constructedObjectId
    }})

}
db.loadServerScripts();

var dt=new Date();

var mnth=(dt.getMonth()+1).toString();

var dte=dt.getDate().toString();

var yr=dt.getFullYear().toString();

var prdt=new Date() - (30*24*60*60*1000);

var pr_dt=new Date(prdt);
var mnth1=(pr_dt.getMonth()+1).toString();
var dte1=pr_dt.getDate().toString();
var yr1=pr_dt.getFullYear().toString();

var file=cat('/opt/app/nas/mongodbscripts/purging/Dhiraj/collection_details_adv.csv');

var rows = file.split(/\r?\n|\r/);

for(var i=0;i < rows.length;i++){


db[rows[i]].find({$and:[{"SCHEDULEDATE": {$lt:mnth+"/"+dte+"/"+yr+" "+"00:00:00"}},{_id: { $lte: objectIdWithTimestamp(mnth1+"/"+dte1+"/"+yr1) }} ]}).count()

var before_purge=db[rows[i]].find().count();

db[rows[i]].remove({$and:[{"SCHEDULEDATE": {$lt:mnth+"/"+dte+"/"+yr+" "+"00:00:00"}},{_id: { $lte: objectIdWithTimestamp(mnth1+"/"+dte1+"/"+yr1) }} ]})

var after_purge=db[rows[i]].find.count();

printjson('DATE : '+ new Date() +'Collection : '+ rows[i] +' Before purge,records count : '+ before_purge + ' After purge,records count : '+ after_purge);

}
