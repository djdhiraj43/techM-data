db.loadServerScripts();

var dt=new Date();

var mnth=(dt.getMonth()+1).toString();

var dte=dt.getDate().toString();

var yr=dt.getFullYear().toString();

var prdt=new Date() - (30*24*60*60*1000);

var pr_dt=new Date(prdt);
var mnth1=(pr_dt.getMonth()+1).toString();
var dte1=pr_dt.getDate().toString();
var yr1=pr_dt.getFullYear().toString();

var file=cat('/opt/app/nas/mongodbscripts/purging/Dhiraj/collection_details_adv.csv');

var rows = file.split(/\r?\n|\r/);

print("========================================"+Date()+"==============================================");

for(var i=0;i < rows.length;i++){


var before_purge=db[rows[i]].find({$and:[{"SCHEDULEDATE": {$lt:mnth+"/"+dte+"/"+yr+" "+"00:00:00"}},{_id: { $lte: objectIdWithTimestamp(mnth1+"/"+dte1+"/"+yr1) }} ]}).count()

printjson('DATE : '+ new Date() +'Collection : '+ rows[i] +' Before purge,records count : '+ before_purge);

}
