#!/bin/bash

#. /opt/app/nas/mongodbscripts/purge_db_details.cfg
. /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/db_details_for_count.cfg

if [ "$switch" == "ON" ]
then

echo "$host $port $user $pwd $authdb"
echo "Counting Started....."

dt=`date +%d%b%Y_%H_%M`;
#lFile="RAPTOR_count_$dt";
logFile="RAPTOR_count_$dt".log

rm /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/RAPTOR_count*

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/mongodb_count_script.js | tee /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/"$logFile" >> /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/permanent_RPTOR_cnt.log

echo "Hi,
Please find the collection count details of RAPTOR in the attachment for DATE:`date`"|mail -s "Collection count on: `date`" -a /opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/"$logFile" db00494888@techmahindra.com vc00500097@techmahindra.com

echo "$logFile"

echo "Counting End."
fi

