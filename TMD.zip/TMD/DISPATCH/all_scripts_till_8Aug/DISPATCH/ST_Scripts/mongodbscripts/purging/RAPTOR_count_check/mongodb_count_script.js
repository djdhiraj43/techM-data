var file = cat('/opt/app/nas/mongodbscripts/purging/RAPTOR_count_check/collection_details_for_count.csv');
var rows = file.split(/\r?\n|\r/);
for(var singleRow=0;singleRow < rows.length;singleRow++)
{
    collection = rows[singleRow];
    if(typeof(collection)!='undefined')
    {
		currentDate = Date.now();
		actual_cnt = db[collection].find().count()
		printjson('DATE : '+ new Date() +'Collection : '+ collection +' Records count : '+ actual_cnt);
    }
}

