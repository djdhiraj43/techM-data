var isfunctionExists = db.system.js.find({"_id":"objectIdWithTimestamp"}).count()
if(isfunctionExists==0)
{
   db.system.js.save (
   {
     _id: "objectIdWithTimestamp",
     value: function objectIdWithTimestamp (timestamp) {
    
         if (typeof(timestamp) == 'string')
         {
             timestamp = new Date(timestamp);
         }
   
    
      var hexSeconds = Math.floor(timestamp/1000).toString(16);
    
    var constructedObjectId = ObjectId(hexSeconds + "0000000000000000");
    return constructedObjectId
    }})

}
db.loadServerScripts();

var file = cat('/opt/app/nas/mongodbscripts/purging/collection_details.csv');
var rows = file.split(/\r?\n|\r/);
for(var singleRow=0;singleRow < rows.length-1;singleRow++)
{
    rowCells = rows[singleRow].split(',');
    collection = rowCells[0];
    days = rowCells[1];
print(singleRow)
print(rowCells[0])
    if(typeof(collection)!='undefined')
    {
		currentDate = Date.now();
		newDate =new Date(ISODate().getTime() - parseInt(rowCells[1])*24*3600*1000)
		purgeDate = newDate.getFullYear()+"/"+ (((newDate.getMonth()+1) < 10 )? "0"+ (newDate.getMonth()+1):(newDate.getMonth()+1))+"/"+((newDate.getDate() < 10)? "0"+ newDate.getDate():newDate.getDate());
		actual_cnt = db[collection].find().count()
		db[collection].remove({ _id: { $lte: objectIdWithTimestamp(purgeDate) } })
		afterpurge_cnt = db[collection].find().count()
		printjson('DATE : '+ new Date() +'Collection : '+ collection +' Before purge,records count : '+ actual_cnt + ' After purge,records count : '+ afterpurge_cnt);
    }
}

