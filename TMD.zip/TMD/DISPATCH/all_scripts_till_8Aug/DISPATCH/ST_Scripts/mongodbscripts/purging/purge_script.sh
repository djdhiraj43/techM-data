#!/bin/bash

#. /opt/app/nas/mongodbscripts/purge_db_details.cfg
. /opt/app/nas/mongodbscripts/purging/purge_db_details.cfg
echo "$host $port $user $pwd $authdb"
echo "Purging Started....."

/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/purging/mongodb_purge_script.js >>/opt/app/nas/mongodbscripts/purging/purge_details.log

echo "Purging End."
