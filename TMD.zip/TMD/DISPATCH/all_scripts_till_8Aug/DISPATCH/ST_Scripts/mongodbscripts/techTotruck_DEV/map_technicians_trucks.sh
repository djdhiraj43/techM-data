#!/bin/bash

. /opt/app/nas/mongodbscripts/techTotruck_DEV/techtotruck_db_details.cfg

echo "$host $port $user $pwd $authdb"
echo "Mapping Started....."
#mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /tmp/map_tech_truck.js 
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/techTotruck_DEV/daily_job_map_tech_truck.js >> /opt/app/nas/mongodbscripts/techTotruck_DEV/tech_trucklog.log
echo "Mapping End."
