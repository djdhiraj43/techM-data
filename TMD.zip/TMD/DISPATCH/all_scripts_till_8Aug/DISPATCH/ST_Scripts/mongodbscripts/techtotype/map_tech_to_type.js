var collExists_se = db.MAPTECHTYPE_SE.count()
if(collExists_se>0)
{    
    db.MAPTECHTYPE_SE.remove({})
}
db.FORCESE.XBFTECH_T_SE.find({}).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    var grpId = doc.GROUPID
    str1 = grpId.charAt(2)
    str2 = grpId.charAt(3)
    str3 = grpId.charAt(4)
    if (str1 == "_" && str2 == "T" && str3 == "_")
    {
        db.MAPTECHTYPE_SE.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":supvid})
    }
	else if(str1 == "_" && str2 == "E" && str3 == "_")
	{
		db.MAPTECHTYPE_SE.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
	}
    })

var map_se_count = db.MAPTECHTYPE_SE.count()
print("map_se_count : "+ map_se_count)

var collExists_mw = db.MAPTECHTYPE_MW.count()
if(collExists_mw>0)
{    
    db.MAPTECHTYPE_MW.remove({})
}
db.FORCEMW.XBFTECH_T_MW.find({}).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    var grpId = doc.GROUPID
    str1 = grpId.charAt(2)
    str2 = grpId.charAt(3)
    str3 = grpId.charAt(4)
    if (str1 == "_" && str2 == "T" && str3 == "_")
    {
        db.MAPTECHTYPE_MW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":supvid})
    }
	else if(str1 == "_" && str2 == "E" && str3 == "_")
	{
		db.MAPTECHTYPE_MW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
	}
    })

var map_mw_count = db.MAPTECHTYPE_MW.count()
print("map_mw_count : "+ map_mw_count)

var collExists_sw = db.MAPTECHTYPE_SW.count()
if(collExists_sw>0)
{    
    db.MAPTECHTYPE_SW.remove({})
}
db.FORCESW.XBFTECH_T_SW.find({}).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    var grpId = doc.GROUPID
    str1 = grpId.charAt(2)
    str2 = grpId.charAt(3)
    str3 = grpId.charAt(4)
    if (str1 == "_" && str2 == "T" && str3 == "_")
    {
        db.MAPTECHTYPE_SW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":supvid})
    }
	else if(str1 == "_" && str2 == "E" && str3 == "_")
	{
		db.MAPTECHTYPE_SW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
	}
    })

var map_sw_count = db.MAPTECHTYPE_SW.count()
print("map_sw_count : "+ map_sw_count)

var collExists_w = db.MAPTECHTYPE_W.count()
if(collExists_w>0)
{    
    db.MAPTECHTYPE_W.remove({})
}
db.FORCEW.XBFTECH_T_W.find({}).forEach(function(doc){
   var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    var grpId = doc.GROUPID
    str1 = grpId.charAt(2)
    str2 = grpId.charAt(3)
    str3 = grpId.charAt(4)
    if (str1 == "_" && str2 == "T" && str3 == "_")
    {
        db.MAPTECHTYPE_W.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":supvid})
    }
	else if (str1 == "_" && str2 == "E" && str3 == "_")
	{
		db.MAPTECHTYPE_W.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
	}
    })

var map_w_count = db.MAPTECHTYPE_W.count()
print("map_w_count : "+ map_w_count)
