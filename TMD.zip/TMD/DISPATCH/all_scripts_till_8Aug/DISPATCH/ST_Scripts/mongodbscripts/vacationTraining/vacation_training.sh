#!/bin/bash

. /opt/app/nas/mongodbscripts/vacationTraining/vacationtraining_db_details.cfg

echo "$host $port $user $pwd $authdb"
echo "Mapping Started....."
#mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /tmp/map_tech_truck.js 
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel70-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /opt/app/nas/mongodbscripts/vacationTraining/map_vacation_training.js >> /opt/app/nas/mongodbscripts/vacationTraining/vacation_training.log
echo "Mapping End."

