todaydate =ISODate().getFullYear()+"-"+ (((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"-"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+":00:00:00";
tdate = ISODate().getFullYear()+"-"+ (((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"-"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())
var collExists = db.MAPTECHSCHEDULEVACATION.count()
if(collExists > 0)
{    
    db.MAPTECHSCHEDULEVACATION.remove({})	
}
db.FORCEMW.XBFTECHDATESCHEDPARAMS_T_MW.aggregate([
 {
     "$lookup": {
                  "from": "FORCEMW.XBFTECHWL_T_MW",
                  "localField": "TECHNICIANID",
                  "foreignField": "TECHNICIANID",
                  "as": "SCH_WL_MW"
                }
  },
  {"$unwind": "$SCH_WL_MW"},
  {"$project":
      {
          "TECHNICIANID":"$TECHNICIANID",
          "TECHNICIANIDResult":{"$eq": ["$TECHNICIANID", "$SCH_WL_MW.TECHNICIANID"]},
          "SCHEDULEDATE":"$SCHEDULEDATE",
          "SCHEDULESCHDate" : {"$substr":["$SCHEDULEDATE",0,10]},
          "SCHEDULEWLDate" : {"$substr":["$SCH_WL_MW.SCHEDULEDATE",0,10]},
          "testEQ": {"$eq": [{"$substr":["$SCHEDULEDATE",0,10]}, {"$substr":["$SCH_WL_MW.SCHEDULEDATE",0,10]}]},
          "SCHEDULEDATEResult":{"$eq": ["$SCHEDULEDATE", "$SCH_WL_MW.SCHEDULEDATE"]},
          "LUNCHSTARTTIME":"$LUNCHSTARTTIME",
          "ESTIMATEDSTARTDATETIME":"$SCH_WL_MW.ESTIMATEDSTARTDATETIME",
          "ESTIMATEDCOMPLETIONDATETIME":"$SCH_WL_MW.ESTIMATEDCOMPLETIONDATETIME",
          "SCHEDULESTART":"$SCHEDULESTART",
          "SCHEDULEEND":"$SCHEDULEEND",
          "ACTIVITYTYPE":"$SCH_WL_MW.ACTIVITYTYPE",
          "ACTIVITYACTION":"$SCH_WL_MW.ACTIVITYACTION"
      }
  }
,
  {
      "$match": 
      {
         "$and": [{"TECHNICIANIDResult": {"$eq": true}},{"SCHEDULEDATEResult": {"$eq": true}}
         ,{"SCHEDULESCHDate":{"$eq":tdate}}
         ]
      }
  }
]).forEach(function(doc){
    var formateddate="";
    var lunchenddate="null";
    if((doc.LUNCHSTARTTIME == "null") || (doc.LUNCHSTARTTIME == "") || (doc.LUNCHSTARTTIME == null))
    {   
      
    }    
    else
    { 
        strdate = doc.LUNCHSTARTTIME
        strdate = strdate.replace(/-/g,'/')     
        strdate = strdate.replace(/:/,' ')       
        formateddate = new Date(strdate)
        formateddate.setMinutes(formateddate.getMinutes() + parseInt(doc.LUNCHLENGTH =='null' ? '0':doc.LUNCHLENGTH))
        if((doc.LUNCHENDTIME != "") || (doc.LUNCHENDTIME != "null") || (doc.LUNCHENDTIME != null) )
        {
               lunchenddate  = [formateddate.getDate(),
               formateddate.getMonth() + 1 ,
               formateddate.getFullYear()].join('-')+' '+
              [formateddate.getHours(),
               formateddate.getMinutes(),
               formateddate.getSeconds()].join(':');
        }
   
    }

        db.MAPTECHSCHEDULEVACATION.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE
            ,"LUNCHSTARTTIME":doc.LUNCHSTARTTIME,"LUNCHENDTIME":lunchenddate,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,
            "SCHEDULESTART":doc.SCHEDULESTART,"SCHEDULEEND":doc.SCHEDULEEND,"ACTIVITYTYPE":doc.ACTIVITYTYPE
            ,"ACTIVITYACTION":doc.ACTIVITYACTION})
})
//-------------------------------
db.FORCESW.XBFTECHDATESCHEDPARAMS_T_SW.aggregate([
 {
     "$lookup": {
                  "from": "FORCESW.XBFTECHWL_T_SW",
                  "localField": "TECHNICIANID",
                  "foreignField": "TECHNICIANID",
                  "as": "SCH_WL_SW"
                }
  },
  {"$unwind": "$SCH_WL_SW"},
  {"$project":
      {
          "TECHNICIANID":"$TECHNICIANID",
          "TECHNICIANIDResult":{"$eq": ["$TECHNICIANID", "$SCH_WL_SW.TECHNICIANID"]},
          "SCHEDULEDATE":"$SCHEDULEDATE",
          "SCHEDULESCHDate" : {"$substr":["$SCHEDULEDATE",0,10]},
          "SCHEDULEWLDate" : {"$substr":["$SCH_WL_SW.SCHEDULEDATE",0,10]},
          "testEQ": {"$eq": [{"$substr":["$SCHEDULEDATE",0,10]}, {"$substr":["$SCH_WL_SW.SCHEDULEDATE",0,10]}]},
          "SCHEDULEDATEResult":{"$eq": ["$SCHEDULEDATE", "$SCH_WL_SW.SCHEDULEDATE"]},
          "LUNCHSTARTTIME":"$LUNCHSTARTTIME",
          "ESTIMATEDSTARTDATETIME":"$SCH_WL_SW.ESTIMATEDSTARTDATETIME",
          "ESTIMATEDCOMPLETIONDATETIME":"$SCH_WL_SW.ESTIMATEDCOMPLETIONDATETIME",
          "SCHEDULESTART":"$SCHEDULESTART",
          "SCHEDULEEND":"$SCHEDULEEND",
          "ACTIVITYTYPE":"$SCH_WL_SW.ACTIVITYTYPE",
          "ACTIVITYACTION":"$SCH_WL_SW.ACTIVITYACTION"        
      }
  },
  {
      "$match": 
      {
         "$and": [{"TECHNICIANIDResult": {"$eq": true}},{"SCHEDULEDATEResult": {"$eq": true}}
         ,{"SCHEDULESCHDate":{"$eq":tdate}}
         ]
      }
  }
  
]).forEach(function(doc){
    var formateddate="";
    var lunchenddate="null";
    if((doc.LUNCHSTARTTIME == "null") || (doc.LUNCHSTARTTIME == "") || (doc.LUNCHSTARTTIME == null))
    {   
      
    }    
    else
    { 
        strdate = doc.LUNCHSTARTTIME
        strdate = strdate.replace(/-/g,'/')     
        strdate = strdate.replace(/:/,' ')       
        formateddate = new Date(strdate)
        formateddate.setMinutes(formateddate.getMinutes() + parseInt(doc.LUNCHLENGTH =='null' ? '0':doc.LUNCHLENGTH))
        if((doc.LUNCHENDTIME != "") || (doc.LUNCHENDTIME != "null") || (doc.LUNCHENDTIME != null) )
        {
               lunchenddate  = [formateddate.getDate(),
               formateddate.getMonth() + 1 ,
               formateddate.getFullYear()].join('-')+' '+
              [formateddate.getHours(),
               formateddate.getMinutes(),
               formateddate.getSeconds()].join(':');
        }
   
    }

        db.MAPTECHSCHEDULEVACATION.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE
            ,"LUNCHSTARTTIME":doc.LUNCHSTARTTIME,"LUNCHENDTIME":lunchenddate,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,
            "SCHEDULESTART":doc.SCHEDULESTART,"SCHEDULEEND":doc.SCHEDULEEND,"ACTIVITYTYPE":doc.ACTIVITYTYPE
            ,"ACTIVITYACTION":doc.ACTIVITYACTION})
})
//----------------------------------------------------
db.FORCEW.XBFTECHDATESCHEDPARAMS_T_W.aggregate([
 {
     "$lookup": {
                  "from": "FORCEW.XBFTECHWL_T_W",
                  "localField": "TECHNICIANID",
                  "foreignField": "TECHNICIANID",
                  "as": "SCH_WL_W"
                }
  },
  {"$unwind": "$SCH_WL_W"},
  {"$project":
      {
          "TECHNICIANID":"$TECHNICIANID",
          "TECHNICIANIDResult":{"$eq": ["$TECHNICIANID", "$SCH_WL_W.TECHNICIANID"]},
          "SCHEDULEDATE":"$SCHEDULEDATE",
          "SCHEDULESCHDate" : {"$substr":["$SCHEDULEDATE",0,10]},
          "SCHEDULEWLDate" : {"$substr":["$SCH_WL_W.SCHEDULEDATE",0,10]},
          "testEQ": {"$eq": [{"$substr":["$SCHEDULEDATE",0,10]}, {"$substr":["$SCH_WL_W.SCHEDULEDATE",0,10]}]},
          "SCHEDULEDATEResult":{"$eq": ["$SCHEDULEDATE", "$SCH_WL_W.SCHEDULEDATE"]},
          "LUNCHSTARTTIME":"$LUNCHSTARTTIME",
          "ESTIMATEDSTARTDATETIME":"$SCH_WL_W.ESTIMATEDSTARTDATETIME",
          "ESTIMATEDCOMPLETIONDATETIME":"$SCH_WL_W.ESTIMATEDCOMPLETIONDATETIME",
          "SCHEDULESTART":"$SCHEDULESTART",
          "SCHEDULEEND":"$SCHEDULEEND",
          "ACTIVITYTYPE":"$SCH_WL_W.ACTIVITYTYPE",
          "ACTIVITYACTION":"$SCH_WL_W.ACTIVITYACTION"          
      }
  },
  {
      "$match": 
      {
         "$and": [{"TECHNICIANIDResult": {"$eq": true}},{"SCHEDULEDATEResult": {"$eq": true}}
         ,{"SCHEDULESCHDate":{"$eq":tdate}}
         ]
      }
  }
]).forEach(function(doc){
    var formateddate="";
    var lunchenddate="null";
    if((doc.LUNCHSTARTTIME == "null") || (doc.LUNCHSTARTTIME == "") || (doc.LUNCHSTARTTIME == null))
    {   
      
    }    
    else
    { 
        strdate = doc.LUNCHSTARTTIME
        strdate = strdate.replace(/-/g,'/')     
        strdate = strdate.replace(/:/,' ')       
        formateddate = new Date(strdate)
        formateddate.setMinutes(formateddate.getMinutes() + parseInt(doc.LUNCHLENGTH =='null' ? '0':doc.LUNCHLENGTH))
        if((doc.LUNCHENDTIME != "") || (doc.LUNCHENDTIME != "null") || (doc.LUNCHENDTIME != null) )
        {
               lunchenddate  = [formateddate.getDate(),
               formateddate.getMonth() + 1 ,
               formateddate.getFullYear()].join('-')+' '+
              [formateddate.getHours(),
               formateddate.getMinutes(),
               formateddate.getSeconds()].join(':');
        }
   
    }

	db.MAPTECHSCHEDULEVACATION.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE
		,"LUNCHSTARTTIME":doc.LUNCHSTARTTIME,"LUNCHENDTIME":lunchenddate,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,
		"SCHEDULESTART":doc.SCHEDULESTART,"SCHEDULEEND":doc.SCHEDULEEND,"ACTIVITYTYPE":doc.ACTIVITYTYPE
		,"ACTIVITYACTION":doc.ACTIVITYACTION})
})
//-----------------------------------------------------
db.FORCEW.XBFTECHDATESCHEDPARAMS_T_SE.aggregate([
 {
     "$lookup": {
                  "from": "FORCEW.XBFTECHWL_T_SE",
                  "localField": "TECHNICIANID",
                  "foreignField": "TECHNICIANID",
                  "as": "SCH_WL_SE"
                }
  },
  {"$unwind": "$SCH_WL_SE"},
  {"$project":
      {
         "TECHNICIANID":"$TECHNICIANID",
          "TECHNICIANIDResult":{"$eq": ["$TECHNICIANID", "$SCH_WL_SE.TECHNICIANID"]},
          "SCHEDULEDATE":"$SCHEDULEDATE",
          "SCHEDULESCHDate" : {"$substr":["$SCHEDULEDATE",0,10]},
          "SCHEDULEWLDate" : {"$substr":["$SCH_WL_SE.SCHEDULEDATE",0,10]},
          "testEQ": {"$eq": [{"$substr":["$SCHEDULEDATE",0,10]}, {"$substr":["$SCH_WL_SE.SCHEDULEDATE",0,10]}]},
          "SCHEDULEDATEResult":{"$eq": ["$SCHEDULEDATE", "$SCH_WL_SE.SCHEDULEDATE"]},
          "LUNCHSTARTTIME":"$LUNCHSTARTTIME",
          "ESTIMATEDSTARTDATETIME":"$SCH_WL_SE.ESTIMATEDSTARTDATETIME",
          "ESTIMATEDCOMPLETIONDATETIME":"$SCH_WL_SE.ESTIMATEDCOMPLETIONDATETIME",
          "SCHEDULESTART":"$SCHEDULESTART",
          "SCHEDULEEND":"$SCHEDULEEND",
          "ACTIVITYTYPE":"$SCH_WL_SE.ACTIVITYTYPE",
          "ACTIVITYACTION":"$SCH_WL_SE.ACTIVITYACTION"           
      }
  },
  {
      "$match": 
      {
         "$and": [{"TECHNICIANIDResult": {"$eq": true}},{"SCHEDULEDATEResult": {"$eq": true}}
         ,{"SCHEDULESCHDate":{"$eq":tdate}}
         ]
      }
  }
]).forEach(function(doc){
    var formateddate="";
    var lunchenddate="null";
    if((doc.LUNCHSTARTTIME == "null") || (doc.LUNCHSTARTTIME == "") || (doc.LUNCHSTARTTIME == null))
    {   
      
    }    
    else
    { 
        strdate = doc.LUNCHSTARTTIME
        strdate = strdate.replace(/-/g,'/')     
        strdate = strdate.replace(/:/,' ')       
        formateddate = new Date(strdate)
        formateddate.setMinutes(formateddate.getMinutes() + parseInt(doc.LUNCHLENGTH =='null' ? '0':doc.LUNCHLENGTH))
        if((doc.LUNCHENDTIME != "") || (doc.LUNCHENDTIME != "null") || (doc.LUNCHENDTIME != null) )
        {
               lunchenddate  = [formateddate.getDate(),
               formateddate.getMonth() + 1 ,
               formateddate.getFullYear()].join('-')+' '+
              [formateddate.getHours(),
               formateddate.getMinutes(),
               formateddate.getSeconds()].join(':');
        }
   
    }

	db.MAPTECHSCHEDULEVACATION.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE
		,"LUNCHSTARTTIME":doc.LUNCHSTARTTIME,"LUNCHENDTIME":lunchenddate,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,
		"SCHEDULESTART":doc.SCHEDULESTART,"SCHEDULEEND":doc.SCHEDULEEND,"ACTIVITYTYPE":doc.ACTIVITYTYPE
		,"ACTIVITYACTION":doc.ACTIVITYACTION})
})