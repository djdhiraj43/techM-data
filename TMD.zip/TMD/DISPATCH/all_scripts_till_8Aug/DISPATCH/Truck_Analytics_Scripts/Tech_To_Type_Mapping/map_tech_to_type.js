
var collExists_se = db.MAPTECHTYPE_SE.count()
if(collExists_se>0)
{    
    db.MAPTECHTYPE_SE.remove({})
}
db.FORCESE.XBFTECH_T_SE.find({"GROUPID":/_T_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    db.MAPTECHTYPE_SE.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":doc.SUPVID})
    })
db.FORCESE.XBFTECH_T_SE.find({"GROUPID":/_E_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
     db.MAPTECHTYPE_SE.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
    })
var map_se_count = db.MAPTECHTYPE_SE.count()
print("map_se_count : "+ map_se_count)

var collExists_mw = db.MAPTECHTYPE_MW.count()
if(collExists_mw>0)
{    
    db.MAPTECHTYPE_MW.remove({})
}
db.FORCEMW.XBFTECH_T_MW.find({"GROUPID":/_T_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    db.MAPTECHTYPE_MW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":doc.SUPVID})
    })
db.FORCEMW.XBFTECH_T_MW.find({"GROUPID":/_E_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
     db.MAPTECHTYPE_MW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
    })
var map_mw_count = db.MAPTECHTYPE_MW.count()
print("map_mw_count : "+ map_mw_count)

var collExists_sw = db.MAPTECHTYPE_SW.count()
if(collExists_sw>0)
{    
    db.MAPTECHTYPE_SW.remove({})
}
db.FORCESW.XBFTECH_T_SW.find({"GROUPID":/_T_/ }).forEach(function(doc){
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    db.MAPTECHTYPE_SW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":doc.SUPVID})
    })
db.FORCESW.XBFTECH_T_SW.find({"GROUPID":/_E_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
     db.MAPTECHTYPE_SW.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
    })
var map_sw_count = db.MAPTECHTYPE_SW.count()
print("map_sw_count : "+ map_sw_count)

var collExists_w = db.MAPTECHTYPE_W.count()
if(collExists_w>0)
{    
    db.MAPTECHTYPE_W.remove({})
}
db.FORCEW.XBFTECH_T_W.find({"GROUPID":/_T_/ }).forEach(function(doc){
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
    db.MAPTECHTYPE_W.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Core","SUPVID":doc.SUPVID})
    })
db.FORCEW.XBFTECH_T_W.find({"GROUPID":/_E_/ }).forEach(function(doc){
    var supvid=null
    if(typeof(doc.SUPVID) != 'undefined')
    {
        supvid = doc.SUPVID
    }
     db.MAPTECHTYPE_W.insert({"TECHNICIANID":doc.TECHNICIANID,"GROUPID":"Premise","SUPVID":supvid})
    })
var map_w_count = db.MAPTECHTYPE_W.count()
print("map_w_count : "+ map_w_count)