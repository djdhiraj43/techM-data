#!/bin/bash

. /tmp/techtotype_db_details.cfg

echo "$host $port $user $pwd $authdb"

echo "Mapping Started....."
#mongo "$host":"$port"/"$connectdb" -u "$user" -p "$pwd" --authenticationDatabase "$authdb" /tmp/map_tech_truck.js 
/opt/app/workload/deployments/servers/mongoDB/mongodb-linux-x86_64-rhel62-3.2.9/bin/mongo "$host":"$port"/"$connectdb" /tmp/map_tech_to_type.js >> /tmp/tech_type.log
echo "Mapping End."

