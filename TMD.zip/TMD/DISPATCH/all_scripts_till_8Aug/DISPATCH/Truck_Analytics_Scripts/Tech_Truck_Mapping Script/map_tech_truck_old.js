//Fetch Distinct Technicians
var techUIDs_se = db.TELCO.GPS_FKEY_SE.distinct('TECHNICIAN_UUID')
todaydate_se=ISODate().getFullYear()+"-"+ (((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"-"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+":00:00:00";
//Check if collection exists
var collExists_se = db.MAP_TECH_TRUCK_SE.count()
if(collExists_se>0)
{    
    db.MAP_TECH_TRUCK_SE.remove({})
}
var sbcVIN =[]
db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_se},"FROM_WHEN":{$lte:todaydate_se}
,"TO_WHEN":{$lte:todaydate_se}}).forEach(function(doc){
    sbcVIN.push(doc.SBC_VIN)
    
    })
db.TELCO.GPS_FKEY_SE.find({"RECORD_TYPE":{$in:["9",9.0]},"SBC_VIN":{$in:sbcVIN},"FROM_WHEN":{$lte:todaydate_se}
,"TO_WHEN":{$lte:todaydate_se}}).forEach(function(doc){	
    db.MAP_TECH_TRUCK_SE.insert({"TECHNICIAN_UUID":doc.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
    //print("Collection: TELCO.GPS_FKEY_SE >> TECHNICIAN_UUID : "+doc.TECHNICIAN_UUID + " TRUCK_ID_NUM " + doc.TRUCK_ID_NUM )
})
var map_se_count = db.MAP_TECH_TRUCK_SE.count()
print("map_se_count : "+ map_se_count)
//---------------------------------------------------
//Fetch Distinct Technicians
var techUIDs_mwsw = db.TELCO.GPS_FKEY_MWSW.distinct('TECHNICIAN_UUID')
todaydate_mwsw=ISODate().getFullYear()+"-"+ (((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"-"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+":00:00:00";
//Check if collection exists
var collExists_mwsw = db.MAP_TECH_TRUCK_MWSW.count()
if(collExists_mwsw>0)
{    
    db.MAP_TECH_TRUCK_MWSW.remove({})
	print('In remove')
}
var sbcVIN_mwsw =[]
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_mwsw},"FROM_WHEN":{$lte:todaydate_mwsw}
,"TO_WHEN":{$lte:todaydate_mwsw}}).forEach(function(doc){
    sbcVIN_mwsw.push(doc.SBC_VIN)
    
    })
   
db.TELCO.GPS_FKEY_MWSW.find({"RECORD_TYPE":{$in:["9",9.0]},"SBC_VIN":{$in:sbcVIN_mwsw},"FROM_WHEN":{$lte:todaydate_mwsw}
,"TO_WHEN":{$lte:todaydate_mwsw}}).forEach(function(doc){
    db.MAP_TECH_TRUCK_MWSW.insert({"TECHNICIAN_UUID":doc.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
    //print("Collection: TELCO.GPS_FKEY_MWSW >> TECHNICIAN_UUID : "+doc.TECHNICIAN_UUID + " TRUCK_ID_NUM " + doc.TRUCK_ID_NUM )
})
var map_mwsw_count = db.MAP_TECH_TRUCK_MWSW.count()
print("map_se_count : "+ map_mwsw_count)
//---------------------------------------------
//Fetch Distinct Technicians
var techUIDs_w = db.TELCO.GPS_FKEY_W.distinct('TECHNICIAN_UUID')
todaydate_w=ISODate().getFullYear()+"-"+ (((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"-"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+":00:00:00";
//Check if collection exists
var collExists_w = db.MAP_TECH_TRUCK_W.count()
if(collExists_w>0)
{    
    db.MAP_TECH_TRUCK_W.remove({})
}
var sbcVIN_w =[]
db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["7",7.0]},"TECHNICIAN_UUID":{$in:techUIDs_w},"FROM_WHEN":{$lte:todaydate_w}
,"TO_WHEN":{$lte:todaydate_w}}).forEach(function(doc){
    sbcVIN_w.push(doc.SBC_VIN)
    
    })
   
db.TELCO.GPS_FKEY_W.find({"RECORD_TYPE":{$in:["9",9.0]},"SBC_VIN":{$in:sbcVIN_w},"FROM_WHEN":{$lte:todaydate_w}
,"TO_WHEN":{$lte:todaydate_w}}).forEach(function(doc){
    db.MAP_TECH_TRUCK_W.insert({"TECHNICIAN_UUID":doc.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
    //print("Collection: TELCO.GPS_FKEY_W >> TECHNICIAN_UUID : "+doc.TECHNICIAN_UUID + " TRUCK_ID_NUM " + doc.TRUCK_ID_NUM )
})
var map_w_count = db.MAP_TECH_TRUCK_W.count()
print("map_se_count : "+ map_w_count)
//---------------------------------------------------------------


