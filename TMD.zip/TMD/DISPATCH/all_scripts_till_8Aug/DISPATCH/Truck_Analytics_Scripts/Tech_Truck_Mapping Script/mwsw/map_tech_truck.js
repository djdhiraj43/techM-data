
//Fetch Distinct TECHNICIAN_UUIDans
var techUIDs_mwsw = db.telco_mwsw_gps_fkey_onetimeload.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

//Check if collection exists
var collExists_mwsw = db.MAP_TECH_TRUCK_MWSW.count()
if(collExists_mwsw>0)
{
    db.MAP_TECH_TRUCK_MWSW.remove({})
}
db.telco_mwsw_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["7",7.0,7]},"TECHNICIAN_UUID":{$in:techUIDs_mwsw}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate)
    //print(row.SBC_VIN)
    if(from_date <= tdate && to_when >= tdate)
    {
        db.telco_mwsw_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){
        db.MAP_TECH_TRUCK_MWSW.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})

        })

    }
})

var map_mwsw_count = db.MAP_TECH_TRUCK_MWSW.count()
print("map_se_count : "+ map_mwsw_count)
//----------------------------------------------