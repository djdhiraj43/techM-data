var arr = db.MAP_TECH_TRUCK_SE.find({"TRUCK_ID_NUM":{$type:1}}).toArray();
var i = 0;
while (i<arr.length){
var num = arr[i].TRUCK_ID_NUM.valueOf().toString();
db.MAP_TECH_TRUCK_SE.update({_id : arr[i]._id},{$set : {TRUCK_ID_NUM : num}});
i=i+1;
}

var arr = db.MAP_TECH_TRUCK_MWSW.find({"TRUCK_ID_NUM":{$type:1}}).toArray();
var i = 0;
while (i<arr.length){
var num = arr[i].TRUCK_ID_NUM.valueOf().toString();
db.MAP_TECH_TRUCK_MWSW.update({_id : arr[i]._id},{$set : {TRUCK_ID_NUM : num}});
i=i+1;
}

var arr = db.MAP_TECH_TRUCK_W.find({"TRUCK_ID_NUM":{$type:1}}).toArray();
var i = 0;
while (i<arr.length){
var num = arr[i].TRUCK_ID_NUM.valueOf().toString();
db.MAP_TECH_TRUCK_W.update({_id : arr[i]._id},{$set : {TRUCK_ID_NUM : num}});
i=i+1;
}

