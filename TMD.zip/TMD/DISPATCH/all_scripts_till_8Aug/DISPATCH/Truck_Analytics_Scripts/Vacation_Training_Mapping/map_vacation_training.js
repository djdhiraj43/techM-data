todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";
var collExists_mw = db.MAPVACATIONTRAINING_MW.count()
if(collExists_mw>0)
{    
    db.MAPVACATIONTRAINING_MW.remove({})
}
db.FORCEMW.XBFTECHWL_T_MW.find({"ACTIVITYTYPE":"U","ACTIVITYACTION":{$in:["TG","VP","MT"]}}).forEach(function(doc){
scheduledatestr = doc.SCHEDULEDATE
newscheduledtstr = scheduledatestr
newscheduledtstr = newscheduledtstr.replace(/-/g,'/')
newscheduledtstr = newscheduledtstr.replace(/:/,' ')
schedule_date = new Date(newscheduledtstr)

schedule_date= new Date(new Date((((schedule_date.getMonth()+1) < 10 )? "0"+ (schedule_date.getMonth()+1):(schedule_date.getMonth()+1))+"/"+
((schedule_date.getDate() < 10)? "0"+ schedule_date.getDate():schedule_date.getDate())+"/"+schedule_date.getFullYear()).setHours(0,0,0,0))    
tdate = new Date(todaydate)
if((schedule_date.getTime()) === (tdate.getTime()))
{
	db.MAPVACATIONTRAINING_MW.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE,"ACTIVITYTYPE":doc.ACTIVITYTYPE
	,"ACTIVITYACTION":doc.ACTIVITYACTION,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,"ESTIMATEDCOMPLETIONDATETIME":doc.ESTIMATEDCOMPLETIONDATETIME})
}
})
var mw_count =db.MAPVACATIONTRAINING_MW.count()
print('MW count: ' + mw_count)
var collExists_se = db.MAPVACATIONTRAINING_SE.count()
if(collExists_se>0)
{    
	db.MAPVACATIONTRAINING_SE.remove({})
}
db.FORCESE.XBFTECHWL_T_SE.find({"ACTIVITYTYPE":"U","ACTIVITYACTION":{$in:["TG","VP","MT"]}}).forEach(function(doc){
scheduledatestr = doc.SCHEDULEDATE
newscheduledtstr = scheduledatestr
newscheduledtstr = newscheduledtstr.replace(/-/g,'/')
newscheduledtstr = newscheduledtstr.replace(/:/,' ')
schedule_date = new Date(newscheduledtstr)
schedule_date= new Date(new Date((((schedule_date.getMonth()+1) < 10 )? "0"+ (schedule_date.getMonth()+1):(schedule_date.getMonth()+1))+"/"+
((schedule_date.getDate() < 10)? "0"+ schedule_date.getDate():schedule_date.getDate())+"/"+schedule_date.getFullYear()).setHours(0,0,0,0))    
tdate = new Date(todaydate)

if((schedule_date.getTime()) === (tdate.getTime()))
{
	db.MAPVACATIONTRAINING_SE.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE,"ACTIVITYTYPE":doc.ACTIVITYTYPE
	,"ACTIVITYACTION":doc.ACTIVITYACTION,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,"ESTIMATEDCOMPLETIONDATETIME":doc.ESTIMATEDCOMPLETIONDATETIME})
}
})

var se_count =db.MAPVACATIONTRAINING_SE.count()
print('SW count: ' + se_count)

var collExists_sw = db.MAPVACATIONTRAINING_SW.count()
if(collExists_sw>0)
{    
    db.MAPVACATIONTRAINING_SW.remove({})
}
db.FORCESW.XBFTECHWL_T_SW.find({"ACTIVITYTYPE":"U","ACTIVITYACTION":{$in:["TG","VP","MT"]}}).forEach(function(doc){
scheduledatestr = doc.SCHEDULEDATE
newscheduledtstr = scheduledatestr
newscheduledtstr = newscheduledtstr.replace(/-/g,'/')
newscheduledtstr = newscheduledtstr.replace(/:/,' ')
schedule_date = new Date(newscheduledtstr)
schedule_date= new Date(new Date((((schedule_date.getMonth()+1) < 10 )? "0"+ (schedule_date.getMonth()+1):(schedule_date.getMonth()+1))+"/"+
((schedule_date.getDate() < 10)? "0"+ schedule_date.getDate():schedule_date.getDate())+"/"+schedule_date.getFullYear()).setHours(0,0,0,0))    
tdate = new Date(todaydate)

if((schedule_date.getTime()) === (tdate.getTime()))
{
	db.MAPVACATIONTRAINING_SW.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE,"ACTIVITYTYPE":doc.ACTIVITYTYPE
	,"ACTIVITYACTION":doc.ACTIVITYACTION,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,"ESTIMATEDCOMPLETIONDATETIME":doc.ESTIMATEDCOMPLETIONDATETIME})
}
})
var sw_count =db.MAPVACATIONTRAINING_SW.count()
print('SW count: ' + sw_count)

var collExists_w = db.MAPVACATIONTRAINING_W.count()
if(collExists_w>0)
{    
    db.MAPVACATIONTRAINING_W.remove({})
}
db.FORCEW.XBFTECHWL_T_W.find({"ACTIVITYTYPE":"U","ACTIVITYACTION":{$in:["TG","VP","MT"]}}).forEach(function(doc){
scheduledatestr = doc.SCHEDULEDATE
newscheduledtstr = scheduledatestr
newscheduledtstr = newscheduledtstr.replace(/-/g,'/')
newscheduledtstr = newscheduledtstr.replace(/:/,' ')
schedule_date = new Date(newscheduledtstr)
schedule_date= new Date(new Date((((schedule_date.getMonth()+1) < 10 )? "0"+ (schedule_date.getMonth()+1):(schedule_date.getMonth()+1))+"/"+
((schedule_date.getDate() < 10)? "0"+ schedule_date.getDate():schedule_date.getDate())+"/"+schedule_date.getFullYear()).setHours(0,0,0,0))   
tdate = new Date(todaydate)
if((schedule_date.getTime()) === (tdate.getTime()))
{
db.MAPVACATIONTRAINING_W.insert({"TECHNICIANID":doc.TECHNICIANID,"SCHEDULEDATE":doc.SCHEDULEDATE,"ACTIVITYTYPE":doc.ACTIVITYTYPE
,"ACTIVITYACTION":doc.ACTIVITYACTION,"ESTIMATEDSTARTDATETIME":doc.ESTIMATEDSTARTDATETIME,"ESTIMATEDCOMPLETIONDATETIME":doc.ESTIMATEDCOMPLETIONDATETIME})
}
})
var w_count =db.MAPVACATIONTRAINING_W.count()
print('W count: ' + w_count)
