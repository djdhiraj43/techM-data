//Fetch Distinct Technicians
var techUIDs_se = db.telco_se_gps_fkey_onetimeload.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

//Check if collection exists
var collExists_se = db.MAP_TECH_TRUCK_SE.count()
if(collExists_se>0)
{    
    db.MAP_TECH_TRUCK_SE.remove({})
}
db.telco_se_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["7",7.0,7]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate)  
    //print(row.SBC_VIN)
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.telco_se_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_SE.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_se_count = db.MAP_TECH_TRUCK_SE.count()
print("map_se_count : "+ map_se_count)
//----------------------------------------------

//Fetch Distinct TECHNICIAN_UUIDans
var techUIDs_se = db.telco_mwsw_gps_fkey_onetimeload.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

//Check if collection exists
var collExists_se = db.MAP_TECH_TRUCK_MWSW.count()
if(collExists_se>0)
{    
    db.MAP_TECH_TRUCK_MWSW.remove({})
}
db.telco_mwsw_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["7",7.0,7]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate)  
    //print(row.SBC_VIN)
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.telco_mwsw_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_MWSW.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_se_count = db.MAP_TECH_TRUCK_MWSW.count()
print("map_se_count : "+ map_se_count)
//----------------------------------------------
//Fetch Distinct TECHNICIAN_UUIDans
var techUIDs_se = db.telco_w_gps_fkey_onetimeload.distinct("TECHNICIAN_UUID")
todaydate=(((ISODate().getMonth()+1) < 10 )? "0"+ (ISODate().getMonth()+1):(ISODate().getMonth()+1))+"/"+
((ISODate().getDate() < 10)? "0"+ ISODate().getDate():ISODate().getDate())+"/"+ISODate().getFullYear() +" 00:00:00";

//Check if collection exists
var collExists_se = db.MAP_TECH_TRUCK_W.count()
if(collExists_se>0)
{    
    db.MAP_TECH_TRUCK_W.remove({})
}
db.telco_w_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["7",7.0,7]},"TECHNICIAN_UUID":{$in:techUIDs_se}}).forEach(function(row){
    from_date = new Date(row.FROM_WHEN)
    to_when = new Date(row.TO_WHEN)
    tdate = new Date(todaydate)  
    //print(row.SBC_VIN)
    if(from_date <= tdate && to_when >= tdate)
    {       
        db.telco_w_gps_fkey_onetimeload.find({"RECORD_TYPE":{$in:["9",9.0,9]},"SBC_VIN":row.SBC_VIN}).forEach(
        function(doc){      
        db.MAP_TECH_TRUCK_W.insert({"TECHNICIAN_UUID":row.TECHNICIAN_UUID,"TRUCK_ID_NUM":doc.TRUCK_ID_NUM})
       
        })
        
    }    
})
var map_se_count = db.MAP_TECH_TRUCK_W.count()
print("map_se_count : "+ map_se_count)
//----------------------------------------------
